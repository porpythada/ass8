package com.example.ass7dialogrv

data class Employee (val name: String, val gender: String, var mail: String, var salary: Int) {
}